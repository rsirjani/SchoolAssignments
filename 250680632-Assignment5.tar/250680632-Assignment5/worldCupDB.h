/*
*Title: World Cup Team Database
*Author: Ramtin Sirjani, 250680632
*Date: Nov 27th 2022
*Purpose: To organize teams for the world cup into a database
*ver 2.0
*/

extern char Select_command; //Input for determining command from first options
extern char Select_operation; //Input for determining command from second options
extern char ch; //Used to flush stdin
